package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String stringOperacao;
    Button zero;
    TextView textViewOperacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zero = findViewById(R.id.button0);
        //Iniciando texto do resultado..
        stringOperacao = (String) textViewOperacao.getText();
        textViewOperacao = findViewById(R.id.textViewOperacao);
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preencher("0");
            }
        });


    }



    private void preencher(String character){
        //Acrescentando caractere ao resultado..
        stringOperacao += character;
        textViewOperacao.setText(stringOperacao);

    }


}
